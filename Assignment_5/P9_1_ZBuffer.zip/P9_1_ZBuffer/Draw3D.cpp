#include <windows.h>
#include "Cube.h"

void setShapeData()
{
  setCubeData(150); 
}

