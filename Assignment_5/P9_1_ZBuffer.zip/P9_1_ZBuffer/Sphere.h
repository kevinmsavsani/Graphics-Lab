void setSphereData(double sphereRadius);
