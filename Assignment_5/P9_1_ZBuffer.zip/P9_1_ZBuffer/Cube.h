void setCubeData(double cubeSide);
